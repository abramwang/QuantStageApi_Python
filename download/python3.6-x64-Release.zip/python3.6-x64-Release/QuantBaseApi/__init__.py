# -*- coding: utf-8 -*-


from QuantBaseApi import PT_QuantApi_Python36


class QuantCallBack(PT_QuantApi_Python36.PT_QuantSpi):
	def __init__(self):
		super(QuantCallBack, self).__init__()
		pass
	#系统回调
	def RtnConnect(self):
		self.OnConnect(self.m_dData["nSrvType"])
	def RtnDisconnect(self):
		self.OnDisconnect(self.m_dData["nSrvType"])
	def RtnUserInfo(self):
		self.OnRtnUserInfo(self.m_dData)
	#交易回调
	def RspOrderInsert(self):
		self.OnRspOrderInsert(self.m_dData, self.nTradeErr)
	def RspOrderDelete(self):
		self.OnRspOrderDelete(self.m_dData, self.nTradeErr)
	def RspQryOrder(self):
		self.OnRspQryOrder(self.m_dData, self.nTradeErr, self.bTradeIsEnd)
	def RspQryMatch(self):
		self.OnRspQryMatch(self.m_dData, self.nTradeErr, self.bTradeIsEnd)
	def RspQryPosition(self):
		self.OnRspQryPosition(self.m_dData, self.nTradeErr, self.bTradeIsEnd)
	def RspQryMaxEntrustCount(self):
		self.OnRspQryMaxEntrustCount(self.m_dData, self.nTradeErr, self.bTradeIsEnd)
	def RtnOrderStatusChangeNotice(self):
		self.OnRtnOrderStatusChangeNotice(self.m_dData)
	def RtnOrderMatchNotice(self):
		self.OnRtnOrderMatchNotice(self.m_dData)
	def RtnUserAuthen(self):
		self.OnRtnUserAuthen(self.m_dData)
	def RtnSimulationAccount(self):
		self.OnRtnSimulationAccount(self.m_dData)
	#行情回调
	def RspHaltingDay(self):
		self.OnRspHaltingDay(self.m_dData)
	def RspSubQuote(self):
		self.OnRspSubQuote(self.m_dData)
	def RtnTradingCode(self):
		self.OnRtnTradingCode(self.m_dData["codes"], self.m_dData["options"])
	def RtnTradingDay(self):
		self.OnRtnTradingDay(self.m_dData["pDay"])
	def RtnHaltingDay(self):
		self.OnRtnHaltingDay(self.m_dData["pDay"])
	def RtnKLine(self):
		self.OnRtnKLine(self.m_dData)
	def RtnTransaction(self):
		self.OnRtnTransaction(self.m_dData)
	def RtnOrderQueue(self):
		self.OnRtnOrderQueue(self.m_dData)
	def RtnOrder(self):
		self.OnRtnOrder(self.m_dData)
	def RtnDayBegin(self):
		self.OnRtnDayBegin(self.m_dData["nReqID"], self.m_dData["pDate"])
	def RtnDayEnd(self):
		self.OnRtnDayEnd(self.m_dData["nReqID"], self.m_dData["pDate"])
	def RtnMarket(self):
		self.OnRtnMarket(self.m_dData)
	def RspQryAccountMaxEntrustCount(self):
		self.OnRspQryAccountMaxEntrustCount(self.m_dData, self.nTradeErr, self.bTradeIsEnd)
	def RtnMaxEntrustCount(self):
		self.OnRtnMaxEntrustCount(self.m_dData)
	def RspTradingDay(self):
		self.OnRspTradingDay(self.m_dData)
	def RtnTimeless(self):
		self.OnRtnTimeless(self.m_dData["nReqID"])
	#重载
	def OnConnect(self, type):
		pass
	def OnDisconnect(self, type):
		pass
	def OnRtnUserInfo(self, pInfo):
		pass
	def OnRspOrderInsert(self, pRsp, nErr):
		pass
	def OnRspOrderDelete(self, pRsp, nErr):
		pass
	def OnRspQryOrder(self, pRsp, nErr, isEnd):
		pass
	def OnRspQryMatch(self, pRsp, nErr, isEnd):
		pass
	def OnRspQryPosition(self, pRsp, nErr, isEnd):
		pass
	def OnRspQryMaxEntrustCount(self, pRsp, nErr, isEnd):
		pass
	def OnRtnOrderStatusChangeNotice(self, pNotice):
		pass
	def OnRtnOrderMatchNotice(self, pNotice):
		pass
	def OnRtnUserAuthen(self, pNotice):
		pass
	def OnRspHaltingDay(self, pData):
		pass
	def OnRspSubQuote(self, pData):
		pass
	def OnRtnTradingCode(self, pWinCode, pOptionCode):
		pass
	def OnRtnTradingDay(self, pDay):
		pass
	def OnRtnHaltingDay(self, pDay):
		pass
	def OnRtnKLine(self, pKline):
		pass
	def OnRtnTransaction(self, pTransaction):
		pass
	def OnRtnOrderQueue(self, pOrderQueue):
		pass
	def OnRtnOrder(self, pOrder):
		pass
	def OnRtnDayBegin(self, nReqId, pDate):
		pass
	def OnRtnDayEnd(self, nReqId, pDate):
		pass
	def OnRtnMarket(self, pMarket):
		pass
	def OnRspQryAccountMaxEntrustCount(self,pRsp, nErr, isEnd):
		pass
	def OnRtnMaxEntrustCount(self,pNotice):
		pass
	def OnRspTradingDay(self,pData):
		pass
	def OnRtnSimulationAccount(self,pData):
		pass
	def OnRtnTimeless(self,nReqId):
		pass

__all__ = ["QuantCallBack", "PT_QuantApi_Python36"]
