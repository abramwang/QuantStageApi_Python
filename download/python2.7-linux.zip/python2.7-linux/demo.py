﻿#encoding:utf-8

from QuantBaseApi import QuantCallBack,PT_QuantApi_Python27

class DataCallBack(QuantCallBack):
    def __init__(self):
        super(DataCallBack, self).__init__()
        self.api = PT_QuantApi_Python27.PT_QuantApi(self, True, "Td_Test", "MD_Real")  #此处设置，创建的是交易的测试环境，以及行情的实时环境    交易生产环境在账号有权限的情况下将Td_Test替换成Td_Real即可
    def OnConnect(self, type):
        print("OnConnnect:", type)
        if type == 2:   #0为实时服务器 1为历史服务器 2为缓存服务器  推荐在0.1.2三种行情服务器全部连接成功后做行情请求能保证全时段行情稳定回调        10为交易服务器，连接成功之后才可做交易业务请求
            self.api.ReqSubQuote(1, ["market"], [""], ["600030.SH"], "2016-07-17 8:30:00", "2017-11-06 24:00:00")
            #self.api.ReqHaltingDay(1, ["600030.SH"], "2016-07-17", "2017-11-06")
        pass
    def OnDisconnect(self, type):
        print("OnDisconnect:", type)
        pass
    def OnRtnUserInfo(self, pInfo):
        print ("OnRtnUserInfo", pInfo)
        pass
    def OnRspOrderInsert(self, pRsp, nErr):
        print ("OnRspOrderInsert", pRsp, " nErr", nErr)
        pass
    def OnRspOrderDelete(self, pRsp, nErr):
        print ("OnRspOrderDelete", pRsp, " nErr", nErr)
        pass
    def OnRspQryOrder(self, pRsp, nErr, isEnd):
        print ("OnRspQryOrder", pRsp, " nErr", nErr, " isEnd", isEnd)
        pass
    def OnRspQryMatch(self, pRsp, nErr, isEnd):
        print ("OnRspQryMatch", pRsp, " nErr", nErr, " isEnd", isEnd)
        pass
    def OnRspQryPosition(self, pRsp, nErr, isEnd):
        print ("OnRspQryPosition", pRsp, " nErr", nErr, " isEnd", isEnd)
        pass
    def OnRspQryMaxEntrustCount(self, pRsp, nErr, isEnd):
        print ("OnRspQryMaxEntrustCount", pRsp, " nErr", nErr, " isEnd", isEnd)
        pass
    def OnRtnOrderStatusChangeNotice(self, pNotice):
        print ("OnRtnOrderStatusChangeNotice", pNotice)
        pass
    def OnRtnOrderMatchNotice(self, pNotice):
        print ("OnRtnOrderMatchNotice", pNotice)
        pass
    def OnRtnUserAuthen(self, pNotice):
        print ("OnRtnUserAuthen", pNotice)
        pass
    def OnRspHaltingDay(self, pData):
        print ("OnRspHaltingDay", pData)
        pass
    def OnRspSubQuote(self, pData):      
        print ("OnRspSubQuote", pData)
        pass
    def OnRtnTradingCode(self, pWinCode, pOptionCode):
        print ("OnRtnTradingCode pWincode", pWinCode, " pOptionCode", pOptionCode)
        pass
    def OnRtnTradingDay(self, pDay):
        print ("OnRtnTradingDay ", pDay)
        pass
    def OnRtnHaltingDay(self, pDay):
        print ("OnRtnHaltingDay ", pDay)
        pass
    def OnRtnKLine(self, pKline):
        print ("OnRtnKLine ", pKline)
        pass
    def OnRtnTransaction(self, pTransaction):
        print ("OnRtnTransaction ", pTransaction)
        pass
    def OnRtnOrderQueue(self, pOrderQueue):
        print ("OnRtnOrderQueue ", pOrderQueue)
        pass
    def OnRtnOrder(self, pOrder):
        print ("OnRtnOrder ", pOrder)
        pass
    def OnRtnDayBegin(self, nReqId, pDate):
        print ("OnRtnDayBegin ", pDate)
        pass
    def OnRtnDayEnd(self, nReqId, pDate):
        print ("OnRtnDayEnd ", pDate)
        pass
    def OnRtnMarket(self, pMarket):
        print ("OnRtnMarket ", pMarket)
        #采集数据进行交易逻辑处理
        #下单
        #req = {"nReqId":1,"nUserInt":1,"nUserDouble":1,"szUserStr":"","szContractCode":"002003.SZ","nOrderPrice":76100,"nOrderVol":200,"nTradeType":2}
        #self.api.OrderInsert(req)
        #撤单
        #req = {"nReqId":1,"nUserInt":1,"nUserDouble":1,"szUserStr":"","nOrderId":112333367011,"szOrderStreamId":""}
        #self.api.OrderDelete(req)
        #查询
        #req = {"nReqId":1,"nUserInt":1,"nUserDouble":1,"szUserStr":"","szContractCode":"002003.SZ"}
        #self.api.QryOrder(req)
        #req = {"nReqId":1,"nUserInt":1,"nUserDouble":1,"szUserStr":"","szContractCode":"002003.SZ"}
        #self.api.QryMatch(req)
        #req = {"nReqId":1,"nUserInt":1,"nUserDouble":1,"szUserStr":"","szContractCode":"002003.SZ"}
        #self.api.QryMaxEntrustCount(req)
        pass
    def OnRspQryAccountMaxEntrustCount(self,pRsp, nErr, isEnd):
        print ("OnRspQryAccountMaxEntrustCount", pRsp)
        pass
    def OnRtnMaxEntrustCount(self,pNotice):
        print ("OnRtnMaxEntrustCount", pNotice)
        pass
    def OnRspTradingDay(self,pData):
        print ("OnRspTradingDay", pData)
        pass
    def OnRspQryAccountInitMaxEntrustCount(self,pRsp, nErr, isEnd):
        print ("OnRspQryAccountInitMaxEntrustCount", pRsp)
        pass
def main():
    mspi = DataCallBack()
    mapi = mspi.api
    PT_QuantApi_Python27.Init()
    #print mapi.GetErrMsg(3)
    #print mapi.getVersion()
    retLog = mapi.Login("test1", "abcd1234")
    print("QuantPlus Login :", retLog)#打印登录返回码
    mapi.Run()

if __name__ == '__main__':
    main()
